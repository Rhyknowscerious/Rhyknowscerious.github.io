#!/data/data/com.termux/files/usr/bin/sh

#curl https://raw.githubusercontent.com/Orachigami/homebridge-android/main/setup.sh | bash

installHomebrew () {
  echo $0 '== Setting up Dpkg options ==' &&
  export DEBIAN_FRONTEND=noninteractive &&
  printf "%b" "Dpkg::Options {\n  \"--force-confnew\";\n}" > $PREFIX/etc/apt/apt.conf.d/local &&
  echo $0 '== Removing invalid repositories ==' &&
  pkg remove -y game-repo &&
  pkg remove -y science-repo &&
  echo $0 '== Installing python, openssl and nodejs ==' &&
  pkg i -y python openssl-1.1 nodejs-lts &&
  echo $0 '== Removing added Dpkg options ==' && {
    if [ -f "$PREFIX/etc/apt/apt.conf.d/local" ];then
      rm "$PREFIX/etc/apt/apt.conf.d/local"
    fi
  } &&
  echo $0 '== Installing homebridge and homebridge-config-ui ==' && { {
    npm list -g | grep -q homebridge@ ||
      npm install -g --unsafe-perm homebridge 
  } && { 
    npm list -g | grep -q homebridge-config-ui-x@ ||
    npm install -g --unsafe-perm homebridge-config-ui-x 
  } } &&
  echo $0 '== Creating default config ==' && {
    if [ ! -d ~/".homebridge" ];then
      mkdir -p ~/".homebridge"
    fi
  } && {
    if [ ! -f ~/.homebridge/config.json ];then
      printf "%b" '{\n  "bridge": {\n   "name": "Homebridge BA3D",\n    "username"    : "0E:F1:D3:85:BA:3D",\n    "port": 51248,\n    "pin": "171-94-744",\n    "advertiser": "bonjour-hap"\n },\n  "accessories": [],\n  "platforms": [\n    {\n         "name": "Config",\n     "port": 8581,\n     "platform": "config",\n     "log": {\n        "method": "file",\n       "path": "/data/data/com.termux/files/home/.homebridge/homebridge.log"\n     }\n   }\n ]\n}\n' > ~/.homebridge/config.json 
    fi
  } &&
  echo $0 '== Adding homebridge commands ==' && {
    if [ ! -f "$PREFIX/bin/hb" ];then
      echo 'exec npx homebridge "$@" 2>&1 | tee ~/.homebridge/homebridge.log' > "$PREFIX/bin/hb" &&
      chmod +x "$PREFIX/bin/hb"
    fi
  } &&
  printf "%b" '== Installation successful ==\nExecute hb command to start\n'
  return $?
}

main () {
  if [ $(which hb) ];then
    echo $0 homebrew already installed
  else
    installHomebrew || return $?
  fi
  return 0
}

main

exit $?

