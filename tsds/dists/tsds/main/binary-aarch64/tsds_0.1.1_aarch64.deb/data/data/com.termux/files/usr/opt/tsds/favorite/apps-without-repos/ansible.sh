#!/data/data/com.termux/files/usr/bin/sh

installAnsible () {
    export RUSTFLAGS="-C lto=n" &&
    pkg install python &&
    pip install wheel --verbose &&
    pkg install rust &&
    export CARGO_BUILD_TARGET=aarch64-linux-android || return 1
    pip install cryptography --verbose || return 2
    pip install ansible --verbos || return 3
    return 0
}

main () {
  if [ $(which ansible) ]; then
    echo $0 ansible already installed
  else
    installAnsible
    return $?
  fi
  return 0

}

main

exit $?
