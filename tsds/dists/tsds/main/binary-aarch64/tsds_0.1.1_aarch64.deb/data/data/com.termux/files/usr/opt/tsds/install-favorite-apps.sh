#!/data/data/com.termux/files/usr/bin/sh

commentChar='#'
appsWithoutRepos=$(ls -A ./favorite/apps-without-repos/)
appsWithRepos=$(grep -v \# ./favorite/apps-with-repos.txt)
aptOnlyApps=$(grep -v \# ./favorite/apps-apt-only.txt)
upgradeableApps=$(apt list --upgradable 2> /dev/null | grep -v "^Listing\.\.\.$")

upgradeExistingAppPackages () {
  if [ "$(printf "$upgradeableApps")" != "" ]; then
    echo $0 up{dat,grad}ing via pkg...
    pkg upgrade || return 1
    echo $0 upgrading pip...
    pip install --upgrade pip --verbose || return 2
  else
    echo $0 No upgradeable apt packages found.
  fi
  return 0
}

installAppsWithRepos () {
  echo $0 Installing apps with termux pkg...
  pkg install $appsWithRepos || return 3
  return 0
}

installAppsWithoutRepos () {
  echo $0 Installing apps without packages...
  for script in $appsWithoutRepos; do
    if [ $(echo "$script" | grep -v "^\.") ]; then
      echo "$0 Installing favorite app \"$script\""
      sh "./favorite/apps-without-repos/$script" --verbose || return 4
    else
      echo "$0 Excluding favorite app \"$script\""
    fi
  done
  return 0
}

installAptOnlyApps () {
  echo $0 Installing apps with apt...
  apt install $aptOnlyApps 2> /dev/null || return 5
  return 0
}

main () {
    upgradeExistingAppPackages && \
    installAppsWithRepos && \
    installAptOnlyApps && \
    installAppsWithoutRepos
  return 0
}

main

exit $?
