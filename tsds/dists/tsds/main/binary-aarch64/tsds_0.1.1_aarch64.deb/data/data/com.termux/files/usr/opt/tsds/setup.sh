#!/data/data/com.termux/files/usr/bin/sh

dependency_apps="git openssh"
installed_apps=$(pkg list-installed)
repo=home.termux
user=Rhyknowscerious
workspace=Rhyknowscerious

update_apps() {
  pkg update && pkg upgrade && return 0 || return 2
}

check_installed_apps() {
  for app in $dependency_apps; do
    printf "%b\n" "$installed_apps" | grep "^$app/" || {
      printf "%b\n" "$app not installed"
      return 3
    }
  done
  return 0
}

install_dependencies() {
  pkg install $dependency_apps && return 0 || return 4
}

configure_ssh_agent() {
  pgrep ssh-agent > /dev/null && {
    printf "%b\n" "ssh-agent already running"
  } || {
    printf "SSH "
    eval $(ssh-agent) || return 5
  }
  return 0
}

#setup_ssh_keys() {
  # Create an SSH key pair
  # Add your key to the SSH agent
  # Provide Bitbucket Cloud with your public key
  # Check that your SSH authentication works
  # https://support.atlassian.com/bitbucket-cloud/docs/set-up-personal-ssh-keys-on-linux/
#}

main() {
  update_apps && \
  check_installed_apps && \
  install_dependencies && \
  configure_ssh_agent && \
  git clone "git@bitbucket.org:$user/$repo.git" && \
  return 0 || return 1
}

main

exit $?
