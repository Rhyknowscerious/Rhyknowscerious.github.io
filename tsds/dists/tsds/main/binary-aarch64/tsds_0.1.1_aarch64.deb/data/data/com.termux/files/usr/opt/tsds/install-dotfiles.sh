#!/data/data/com.termux/files/usr/bin/sh

main () {

	files=$(ls -A ./dotfiles/)

  for file in $files; do

    ln \
      --interactive \
      --symbolic \
      --verbose \
      "$(pwd)/dotfiles/$file" ~/

  done

  return 0

}

main

exit $?
