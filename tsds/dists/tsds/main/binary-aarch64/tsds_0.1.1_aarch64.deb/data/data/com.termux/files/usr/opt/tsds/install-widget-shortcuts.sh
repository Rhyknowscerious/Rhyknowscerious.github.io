#!/data/data/com.termux/files/usr/bin/sh

main () {

  if [ "$1" = "-g" ];then
    ./widget/generate-widget-web-shortcuts.sh
  fi

  cp \
    --interactive \
    --recursive \
    --verbose \
      ./widget/.shortcuts ~/

  return 0

}

main $*

exit $?
