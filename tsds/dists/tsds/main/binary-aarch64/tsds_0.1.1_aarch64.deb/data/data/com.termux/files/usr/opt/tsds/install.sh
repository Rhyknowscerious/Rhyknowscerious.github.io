#!/data/data/com.termux/files/usr/bin/sh

revertLocation="$(pwd)"
appLocation="$PREFIX/opt/tsds"

main () {
  cd $appLocation
  if [ "$1" = "-u" ];then
    echo $0 pkg updating...
    pkg update
  fi
  {  
    # Make symbolic links to files in ./dotfiles in ~/
    echo "$0 installing dot files..."
    ./install-dotfiles.sh
  } && { 
    # Copy ./widget/.shortcuts to ~/
    echo "$0 installing termux widget shortcuts..."
    ./install-widget-shortcuts.sh -g
  } && {
    echo "$0 installing favorite apps..."
    ./install-favorite-apps.sh
  } && {
    echo "$0 auto-removing apps..."
    apt autoremove 2> /dev/null && 
    pkg autoclean
  } || {
    cd $revertLocation
    return $?
  }
  cd $revertLocation
  return 0
}

main $*

exit $?
