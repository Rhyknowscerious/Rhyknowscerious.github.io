#!/data/data/com.termux/files/usr/bin/sh

main() {
  if [ $(which aws) ]; then
    echo $0 awscli already installed
  else
    pip3 install awscli || return 1
  fi
  return 0
}

main

exit $?
