#!/data/data/com.termux/files/usr/bin/sh

tmp="$PREFIX/tmp"
archive="$tmp/terraform_1.5.3_linux_arm64.zip"
url="https://releases.hashicorp.com/terraform/1.5.3/terraform_1.5.3_linux_arm64.zip"
opt=$PREFIX/opt

installTerraform() {
  if [ ! -f $archive ]; then
    wget -O $archive $url || return 1
  fi
  if [ ! -d $opt ]; then
    mkdir $opt || return 2
  fi
  unzip $archive -d $opt || return 3
  ln -isv $opt/terraform $PREFIX/bin || return 4
  return 0
}

main () {
  if [ $(which terraform) ];then
    echo $0 terraform already installed
  else
    installTerraform
    return $?
  fi
  return 0
}

main

exit $?
