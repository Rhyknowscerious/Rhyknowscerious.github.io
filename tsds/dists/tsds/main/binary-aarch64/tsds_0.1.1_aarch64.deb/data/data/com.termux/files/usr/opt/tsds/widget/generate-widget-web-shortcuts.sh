#!/data/data/com.termux/files/usr/bin/sh

header="#!/data/data/com.termux/files/usr/bin/sh"
shortcut_dir="./.shortcuts"
config_file="./widget-web-shortcuts.txt"

main () {
  echo $0 updating shortcuts
  while read line; do
    name=$(printf "%b\n" "$line" | awk '{print $1}')
    url=$(printf "%b\n" "$line" | awk '{print $2}')
    shortcut_path="$shortcut_dir/$name"
    if [ -f $shortcut_path ]; then
      echo $0 skipping existing shortcut $shortcut_path
    else
      echo $0 updating $shortcut_path
      printf \
        "%b\n" \
        "$header\n#$name\ntermux-open-url \"$url\"\nexit 0" \
        > "$shortcut_path"
      chmod 700 "$shortcut_path"
    fi
  done < "$config_file"
  return 0
}

main

exit $?
